package com.controller;

import com.model.Customer;
import com.mysql.cj.protocol.Resultset;

public class customerController {
//	public static String getValue(Resultset rs) {
//		Customer c = new Customer();
////		c.setCust_name(rs.get);
//	}
}
