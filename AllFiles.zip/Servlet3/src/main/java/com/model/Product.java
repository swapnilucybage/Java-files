package com.model;

public class Product {

//	private int p_id;
	private String p_name,p_price,p_availability;
	
	
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public String getP_price() {
		return p_price;
	}
	public void setP_price(String p_price) {
		this.p_price = p_price;
	}
	public String getP_availability() {
		return p_availability;
	}
	public void setP_availability(String p_availability) {
		this.p_availability = p_availability;
	}
	
	
}
